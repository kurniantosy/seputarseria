import "./js/materialize.min.js";
import "./js/script.js";
import "./css/materialize.min.css";
import "./css/index.css";
import "./css/responsive.css";
// disini aku hapus file-file yang engga perlu di bundling